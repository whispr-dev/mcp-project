"""OpenAI minimal API demo (requires OPENAI_API_KEY).

Optional:
  set OPENAI_DEMO_MODEL to override model
"""

import os

def main():
    try:
        from openai import OpenAI
    except Exception as e:
        print("Missing dependency or import failed:", e)
        return

    if not os.getenv("OPENAI_API_KEY"):
        print("Set OPENAI_API_KEY to run this demo.")
        return

    client = OpenAI()
    model = os.getenv("OPENAI_DEMO_MODEL", "gpt-4o-mini")

    try:
        r = client.responses.create(model=model, input="Say 'hello' in 3 words.")
        print(getattr(r, "output_text", None) or str(r)[:120])
    except Exception as e:
        print("API call failed:", e)

if __name__ == "__main__":
    main()
