"""gradio minimal app.

Run:
  python gradio_demo.py
"""

def main():
    try:
        import gradio as gr
    except Exception as e:
        print("Missing dependency or import failed:", e)
        return

    def square(x): return x * x

    demo = gr.Interface(fn=square, inputs="number", outputs="number", title="sm0l gradio")
    demo.launch()

if __name__ == "__main__":
    main()
