# pymupdf_demo

**Deps:** PyMuPDF
