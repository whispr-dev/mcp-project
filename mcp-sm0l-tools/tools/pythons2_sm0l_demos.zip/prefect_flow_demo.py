"""prefect minimal flow"""

def main():
    try:
        from prefect import flow, task
    except Exception as e:
        print("Missing dependency or import failed:", e)
        return
    @task
def add(a, b): return a + b

@flow
def demo():
    return add(2, 3)

print("result", demo())


if __name__ == "__main__":
    main()
