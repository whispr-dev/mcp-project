"""PyMuPDF (fitz) create a PDF"""

def main():
    try:
        import fitz
        import tempfile, pathlib
    except Exception as e:
        print("Missing dependency or import failed:", e)
        return
    doc = fitz.open()
page = doc.new_page()
page.insert_text((72, 72), "sm0l PyMuPDF")
p = pathlib.Path(tempfile.gettempdir()) / "sm0l_pymupdf.pdf"
doc.save(p)
doc.close()
print("wrote", p)


if __name__ == "__main__":
    main()
