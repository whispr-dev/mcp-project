# gradio_demo

**Deps:** gradio

Runs a local UI.
