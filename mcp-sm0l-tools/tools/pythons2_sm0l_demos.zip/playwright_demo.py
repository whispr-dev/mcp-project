"""playwright headless launch"""

def main():
    try:
        from playwright.sync_api import sync_playwright
    except Exception as e:
        print("Missing dependency or import failed:", e)
        return
    with sync_playwright() as p:
    b = p.chromium.launch(headless=True)
    page = b.new_page()
    page.goto("about:blank")
    print("ok")
    b.close()


if __name__ == "__main__":
    main()
