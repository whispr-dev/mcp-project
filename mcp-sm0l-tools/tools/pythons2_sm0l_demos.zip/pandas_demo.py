"""pandas tiny delta column"""

def main():
    try:
        import pandas as pd
    except Exception as e:
        print("Missing dependency or import failed:", e)
        return
    df = pd.DataFrame({"day":[1,2,3], "rev":[10,12,15]})
print(df.assign(delta=df.rev.diff()))


if __name__ == "__main__":
    main()
