# fastapi_app_demo

**Deps:** fastapi, uvicorn

This script defines the app; use uvicorn to serve.
