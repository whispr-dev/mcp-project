"""rich minimal console + table"""

def main():
    try:
        from rich.console import Console
        from rich.table import Table
    except Exception as e:
        print("Missing dependency or import failed:", e)
        return
    c = Console()
t = Table(title="sm0l")
t.add_column("k"); t.add_column("v")
for k, v in {"alpha": 1, "beta": 2}.items():
    t.add_row(k, str(v))
c.print(t)


if __name__ == "__main__":
    main()
