# openai_demo

**Deps:** openai

Requires OPENAI_API_KEY.
