"""typer minimal CLI demo.

Run:
  python typer_demo.py hello --name wofl
"""

def main():
    try:
        import typer
    except Exception as e:
        print("Missing dependency or import failed:", e)
        return

    app = typer.Typer(help="sm0l typer app")

    @app.command()
    def hello(name: str = "world"):
        typer.echo(f"hello {name}")

    app()

if __name__ == "__main__":
    main()
