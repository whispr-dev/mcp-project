# sentence_transformers_demo

**Deps:** sentence-transformers
