# playwright_demo

**Deps:** playwright

May require browser install.
