"""schedule tiny periodic task (3 ticks)"""

def main():
    try:
        import schedule, time
    except Exception as e:
        print("Missing dependency or import failed:", e)
        return
    n = {"c": 0}
def job():
    n["c"] += 1
    print("tick", n["c"])
schedule.every(0.1).seconds.do(job)
while n["c"] < 3:
    schedule.run_pending()
    time.sleep(0.05)


if __name__ == "__main__":
    main()
