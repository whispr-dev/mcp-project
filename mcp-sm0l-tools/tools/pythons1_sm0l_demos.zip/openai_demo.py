"""OpenAI minimal API demo (requires OPENAI_API_KEY).

Uses the modern client interface if installed.
"""

import os

def main():
    try:
        from openai import OpenAI
    except Exception as e:
        print("Missing dependency or import failed:", e)
        return

    if not os.getenv("OPENAI_API_KEY"):
        print("Set OPENAI_API_KEY to run this demo.")
        return

    client = OpenAI()
    try:
        r = client.responses.create(
            model=os.getenv("OPENAI_DEMO_MODEL", "gpt-4o-mini"),
            input="Say 'hello' in 3 words."
        )
        txt = getattr(r, "output_text", None)
        print(txt or str(r)[:120])
    except Exception as e:
        print("API call failed:", e)

if __name__ == "__main__":
    main()
