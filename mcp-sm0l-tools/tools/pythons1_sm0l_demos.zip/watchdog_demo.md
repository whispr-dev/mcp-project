# watchdog_demo

**Deps:** watchdog

Uses a temp directory and stops quickly.
