"""pandas tiny dataframe demo"""

def main():
    try:
        import pandas as pd
    except Exception as e:
        print("Missing dependency or import failed:", e)
        return
    df = pd.DataFrame({"day":[1,2,3],"revenue":[10,12,15]})
    print(df.assign(delta=df.revenue.diff()))

if __name__ == "__main__":
    main()
