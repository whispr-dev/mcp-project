"""schedule minimal periodic task demo (runs ~3 ticks)"""

def main():
    try:
        import schedule, time
    except Exception as e:
        print("Missing dependency or import failed:", e)
        return
    count = {"n":0}
    def job():
        count["n"] += 1
        print("tick", count["n"])
    schedule.every(0.1).seconds.do(job)
    while count["n"] < 3:
        schedule.run_pending()
        time.sleep(0.05)

if __name__ == "__main__":
    main()
