"""loguru minimal logging demo"""

def main():
    try:
        import sys
        from loguru import logger
    except Exception as e:
        print("Missing dependency or import failed:", e)
        return

    logger.add(sys.stderr, level="INFO")
    logger.info("hello from loguru")

if __name__ == "__main__":
    main()
