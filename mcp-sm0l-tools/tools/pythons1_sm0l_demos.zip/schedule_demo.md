# schedule_demo

**Deps:** schedule

Runs a tiny loop and exits after ~3 ticks.
