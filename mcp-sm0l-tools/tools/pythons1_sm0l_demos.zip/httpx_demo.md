# httpx_demo

**Deps:** httpx

Makes a simple GET to httpbin.
