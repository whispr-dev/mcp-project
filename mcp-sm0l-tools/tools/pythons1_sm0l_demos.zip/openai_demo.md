# openai_demo

**Deps:** openai

Requires OPENAI_API_KEY. Model name may be adjusted to your account.
