"""requests minimal GET demo"""

def main():
    try:
        import requests
    except Exception as e:
        print("Missing dependency or import failed:", e)
        return
    r = requests.get("https://httpbin.org/get", timeout=5)
    print(r.status_code, r.json().get("url"))

if __name__ == "__main__":
    main()
