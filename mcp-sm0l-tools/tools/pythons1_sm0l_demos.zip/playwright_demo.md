# playwright_demo

**Deps:** playwright

May download browser binaries on first install.
