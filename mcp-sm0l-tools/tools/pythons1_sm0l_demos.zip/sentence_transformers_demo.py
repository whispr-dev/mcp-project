"""sentence-transformers embedding demo"""

def main():
    try:
        from sentence_transformers import SentenceTransformer
    except Exception as e:
        print("Missing dependency or import failed:", e)
        return
    m = SentenceTransformer("all-MiniLM-L6-v2")
    em = m.encode(["abstract one", "abstract two"])
    print(len(em), len(em[0]))

if __name__ == "__main__":
    main()
