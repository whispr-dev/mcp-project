"""pydantic v2 model validation demo"""

def main():
    try:
        from pydantic import BaseModel, Field
    except Exception as e:
        print("Missing dependency or import failed:", e)
        return
    class User(BaseModel):
        name: str
        age: int = Field(ge=0)
    u = User(name="Ada", age=42)
    print(u.model_dump())

if __name__ == "__main__":
    main()
