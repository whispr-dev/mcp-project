"""httpx simple GET demo"""

def main():
    try:
        import httpx
    except Exception as e:
        print("Missing dependency or import failed:", e)
        return
    r = httpx.get("https://httpbin.org/get", timeout=5.0)
    print(r.status_code, "json keys:", sorted(r.json().keys()))

if __name__ == "__main__":
    main()
