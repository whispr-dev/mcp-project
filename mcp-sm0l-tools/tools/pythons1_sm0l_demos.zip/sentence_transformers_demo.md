# sentence_transformers_demo

**Deps:** sentence-transformers

Downloads a small model on first run.
