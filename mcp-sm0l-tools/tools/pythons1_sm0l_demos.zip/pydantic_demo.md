# pydantic_demo

**Deps:** pydantic>=2
