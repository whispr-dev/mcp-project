"""watchdog file system event demo (temp dir)"""

def main():
    try:
        from watchdog.observers import Observer
    from watchdog.events import FileSystemEventHandler
    import time, tempfile, pathlib
    except Exception as e:
        print("Missing dependency or import failed:", e)
        return
    tmp = pathlib.Path(tempfile.mkdtemp())
    class H(FileSystemEventHandler):
        def on_created(self, e): print("created", pathlib.Path(e.src_path).name)
    h = H(); o = Observer()
    o.schedule(h, str(tmp), recursive=False); o.start()
    (tmp/"demo.txt").write_text("hi", encoding="utf-8")
    time.sleep(0.2)
    o.stop(); o.join()
    print("watched", tmp)

if __name__ == "__main__":
    main()
