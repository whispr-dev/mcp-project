# typer_demo

**Deps:** typer

CLI demo. Run `python typer_demo.py --help`.
