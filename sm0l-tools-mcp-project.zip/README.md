# sm0l-tools-mcp

Bulk MCP server that exposes the **sm0l demo scripts library** as MCP tools, with:
- auto-registration from a bundled manifest
- tool metadata (domain/subdomain/tags/deps)
- **install hints** when a tool fails due to missing dependencies (suggests `pip install -e .[extras]`)

## Quick start

1) Put the extracted scripts in `./tools/` (next to this repo), or set:

```bash
set SM0L_TOOLS_DIR=D:\path\to\extracted\scripts
```

2) Install base + extras you want:

```bash
pip install -e .
pip install -e .[web,viz]
```

3) Run the MCP server (stdio transport):

```bash
sm0l-tools-mcp
```

## Install hints

If a tool fails with a missing module, the tool result includes an `install_hints` object with:
- suggested extras
- pip commands
- system dependency notes (tesseract/ffmpeg/playwright browsers)

Example hint:
`pip install -e .[web,browser]`
