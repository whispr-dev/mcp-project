# sm0l-tools-mcp

Bulk MCP server that exposes the **sm0l demo scripts library** as MCP tools, with:
- auto-registration from a bundled manifest
- tool metadata (domain/subdomain/tags/deps)
- **install hints** when a tool fails due to missing dependencies (suggests `pip install -e .[extras]`)

## Quick start

1) Put the extracted scripts in `./tools/` (next to this repo), or set:

```bash
set SM0L_TOOLS_DIR=D:\path\to\extracted\scripts
```

2) Install base + extras you want:

```bash
pip install -e .
pip install -e .[web,viz]
```

3) Run the MCP server (stdio transport):

```bash
sm0l-tools-mcp
```

## Install hints

If a tool fails with a missing module, the tool result includes an `install_hints` object with:
- suggested extras
- pip commands
- system dependency notes (tesseract/ffmpeg/playwright browsers)

Example hint:
`pip install -e .[web,browser]`

## Robust script discovery

The server tries to resolve each tool's script in this order:
1) exact `SM0L_TOOLS_DIR/source_path` (from manifest)
2) suffix match under `SM0L_TOOLS_DIR` (ending with source_path)
3) basename match (unique)
4) if ambiguous (multiple candidates), it errors and shows candidate paths

If you moved files around, prefer pointing `SM0L_TOOLS_DIR` at the exact extracted root.

## Environment validation

Run `validate_environment` to see which tools are ready in the current venv, and what’s missing.
This returns per-tool readiness plus system dependency checks (tesseract/ffmpeg) and a Playwright browser cache heuristic.
